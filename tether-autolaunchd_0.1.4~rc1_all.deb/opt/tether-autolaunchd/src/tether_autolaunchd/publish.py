from __future__ import annotations

import gzip
import json
import os
import re
import shutil
import subprocess
import urllib.request
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class HomebrewResource:
    name: str
    url: str
    sha256: str


def load_project_metadata(project_root: Path) -> dict[str, object]:
    import tomllib

    pyproject = project_root / "pyproject.toml"
    payload = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    project = payload.get("project")
    if not isinstance(project, dict):
        raise ValueError("pyproject.toml is missing [project] metadata")
    return project


def package_name(project_root: Path) -> str:
    name = load_project_metadata(project_root).get("name")
    if not isinstance(name, str) or not name.strip():
        raise ValueError("project.name must be a non-empty string")
    return name.strip()


def package_version(project_root: Path) -> str:
    version = load_project_metadata(project_root).get("version")
    if not isinstance(version, str) or not version.strip():
        raise ValueError("project.version must be a non-empty string")
    return version.strip()


def package_description(project_root: Path) -> str:
    description = load_project_metadata(project_root).get("description")
    if not isinstance(description, str) or not description.strip():
        raise ValueError("project.description must be a non-empty string")
    return description.strip()


def package_maintainer(project_root: Path) -> str:
    project = load_project_metadata(project_root)
    people = project.get("maintainers")
    if not isinstance(people, list) or not people:
        people = project.get("authors")
    if not isinstance(people, list) or not people:
        raise ValueError("project.maintainers or project.authors must contain at least one entry")
    first = people[0]
    if not isinstance(first, dict):
        raise ValueError("project maintainer entry must be a table")
    name = first.get("name")
    email = first.get("email")
    if not isinstance(name, str) or not name.strip():
        raise ValueError("project maintainer name must be a non-empty string")
    if not isinstance(email, str) or not email.strip():
        raise ValueError("project maintainer email must be a non-empty string")
    return f"{name.strip()} <{email.strip()}>"


def project_homepage(project_root: Path) -> str:
    project = load_project_metadata(project_root)
    urls = project.get("urls", {})
    if isinstance(urls, dict):
        homepage = urls.get("Homepage") or urls.get("Repository")
        if isinstance(homepage, str) and homepage.strip():
            return homepage.strip()
    raise ValueError("project.urls.Homepage or project.urls.Repository must be set")


def debian_package_version(version: str) -> str:
    return re.sub(r"(?<=\d)(a|b|rc)(\d+)$", r"~\1\2", version)


def runtime_dependency_names(project_root: Path) -> tuple[str, ...]:
    dependencies = load_project_metadata(project_root).get("dependencies", [])
    if not isinstance(dependencies, list):
        raise ValueError("project.dependencies must be a list")
    names: list[str] = []
    for dependency in dependencies:
        if not isinstance(dependency, str):
            continue
        match = re.match(r"[A-Za-z0-9_.-]+", dependency.strip())
        if match is None:
            continue
        names.append(match.group(0))
    return tuple(names)


def formula_class_name(raw_name: str) -> str:
    return "".join(part.capitalize() for part in re.split(r"[-_.]+", raw_name) if part)


def render_homebrew_formula(
    *,
    name: str,
    description: str,
    homepage: str,
    version: str,
    sdist_url: str,
    sdist_sha256: str,
    resources: tuple[HomebrewResource, ...],
    python_formula: str = "python@3.12",
) -> str:
    resource_lines: list[str] = []
    for resource in resources:
        resource_lines.extend(
            [
                f'  resource "{resource.name}" do',
                f'    url "{resource.url}"',
                f'    sha256 "{resource.sha256}"',
                "  end",
                "",
            ]
        )
    resources_block = "\n".join(resource_lines).rstrip()
    resources_block = f"{resources_block}\n\n" if resources_block else ""
    class_name = formula_class_name(name)
    return (
        f"class {class_name} < Formula\n"
        "  include Language::Python::Virtualenv\n\n"
        f'  desc "{description}"\n'
        f'  homepage "{homepage}"\n'
        f'  url "{sdist_url}"\n'
        f'  sha256 "{sdist_sha256}"\n'
        '  license "MIT"\n'
        f'  depends_on "{python_formula}"\n\n'
        f"{resources_block}"
        "  def install\n"
        "    virtualenv_install_with_resources\n"
        "  end\n\n"
        "  test do\n"
        f'    assert_match "TAD_TETHER_BIN=tether", shell_output("#{{bin}}/{name} print-env")\n'
        "  end\n"
        "end\n"
    )


def fetch_pypi_sdist(name: str, version: str) -> HomebrewResource:
    url = f"https://pypi.org/pypi/{name}/{version}/json"
    with urllib.request.urlopen(url) as response:  # noqa: S310
        payload = json.loads(response.read().decode("utf-8"))
    for entry in payload.get("urls", []):
        if entry.get("packagetype") != "sdist":
            continue
        digests = entry.get("digests", {})
        sha256 = digests.get("sha256")
        resource_url = entry.get("url")
        if isinstance(resource_url, str) and isinstance(sha256, str):
            return HomebrewResource(name=name, url=resource_url, sha256=sha256)
    raise ValueError(f"No sdist found on PyPI for {name}=={version}")


def write_flat_apt_overlay(
    repo_dir: Path,
    deb_path: Path,
    *,
    origin: str = "realagiorganization",
    label: str = "tether-autolaunchd",
    suite: str = "stable",
    codename: str = "stable",
    description: str = "Signed flat APT repository for tether-autolaunchd.",
    gpg_key_id: str | None = None,
    gpg_home: Path | None = None,
    gpg_passphrase: str | None = None,
    public_key_output: Path | None = None,
) -> tuple[Path, Path, Path, Path, Path | None, Path | None]:
    repo_dir.mkdir(parents=True, exist_ok=True)
    target_deb = repo_dir / deb_path.name
    if deb_path.resolve() != target_deb.resolve():
        shutil.copy2(deb_path, target_deb)

    result = subprocess.run(
        ["dpkg-scanpackages", "--multiversion", "."],
        check=True,
        cwd=repo_dir,
        text=True,
        capture_output=True,
    )
    packages_path = repo_dir / "Packages"
    packages_path.write_text(result.stdout, encoding="utf-8")
    packages_gz_path = repo_dir / "Packages.gz"
    with gzip.open(packages_gz_path, "wb") as handle:
        handle.write(result.stdout.encode("utf-8"))

    release_result = subprocess.run(
        [
            "apt-ftparchive",
            "-o",
            f"APT::FTPArchive::Release::Origin={origin}",
            "-o",
            f"APT::FTPArchive::Release::Label={label}",
            "-o",
            f"APT::FTPArchive::Release::Suite={suite}",
            "-o",
            f"APT::FTPArchive::Release::Codename={codename}",
            "-o",
            "APT::FTPArchive::Release::Architectures=all",
            "-o",
            "APT::FTPArchive::Release::Components=main",
            "-o",
            f"APT::FTPArchive::Release::Description={description}",
            "release",
            ".",
        ],
        check=True,
        cwd=repo_dir,
        text=True,
        capture_output=True,
    )
    release_path = repo_dir / "Release"
    release_path.write_text(release_result.stdout, encoding="utf-8")

    inrelease_path: Path | None = None
    release_gpg_path: Path | None = None
    if gpg_key_id:
        gpg_env = dict(os.environ)
        if gpg_home is not None:
            gpg_env["GNUPGHOME"] = str(gpg_home)
        gpg_base = [
            "gpg",
            "--batch",
            "--yes",
            "--pinentry-mode",
            "loopback",
            "--local-user",
            gpg_key_id,
        ]
        if gpg_passphrase is not None:
            gpg_base.extend(["--passphrase", gpg_passphrase])
        inrelease_path = repo_dir / "InRelease"
        subprocess.run(
            [
                *gpg_base,
                "--output",
                str(inrelease_path),
                "--clearsign",
                str(release_path),
            ],
            check=True,
            cwd=repo_dir,
            env=gpg_env,
        )
        release_gpg_path = repo_dir / "Release.gpg"
        subprocess.run(
            [
                *gpg_base,
                "--output",
                str(release_gpg_path),
                "--detach-sign",
                str(release_path),
            ],
            check=True,
            cwd=repo_dir,
            env=gpg_env,
        )
        if public_key_output is not None:
            subprocess.run(
                [
                    "gpg",
                    "--batch",
                    "--yes",
                    "--output",
                    str(public_key_output),
                    "--export",
                    gpg_key_id,
                ],
                check=True,
                cwd=repo_dir,
                env=gpg_env,
            )

    return target_deb, packages_path, packages_gz_path, release_path, inrelease_path, release_gpg_path
